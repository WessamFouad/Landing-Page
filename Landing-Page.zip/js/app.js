/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/

const navigation = document.getElementById('navbar__list');
const sections = document.querySelectorAll('section');
const navLP = document.createDocumentFragment();

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/

/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/
 // Create Nav
    sections.forEach(section => {

        let li = document.createElement('li');
        let A = document.createElement('a');
        let sectionID = section.getAttribute('data-nav');
        let textNode = document.createTextNode(sectionID);


        A.appendChild(textNode);

        A.addEventListener("click",  () => {  
            section.scrollIntoView();
         });

        li.appendChild(A);
        

        navLP.appendChild(li);
        
    });
    
    navigation.appendChild(navLP);

// Add class 'active' to section when near top of viewport
const offset = (section) => {
    return Math.floor(section.getBoundingClientRect().top);
};


// Adding Active
const addActive = (condition, section) => {
    if(condition){
        section.classList.add('your-active-class');
        section.style.backgroundcolor = "rgb(139, 69, 19);";
    };
};

// Remove Active
const removeActive = (section) => {
    section.classList.remove('your-active-class');
    section.style.cssText = "background-color: linear-gradient(0deg, rgba(255,255,255,.1) 0%, rgba(255,255,255,.2) 100%)";
};

// Inviewport
const sectionActive = () => {
    sections.forEach(section => {
        const elementOffset = offset(section);

        inViewPort = () => elementOffset < 100 && elementOffset >= -100;

        removeActive(section);
        addActive(inViewPort(),section);
    });
};

window.addEventListener('scroll' ,sectionActive);

// Scroll to anchor ID using scrollTO event

const scrolling = () => {

    const links = document.querySelectorAll('.navbar__menu a');
    links.forEach(link => {
        link.addEventListener('click', () => {
            for(i = 0 ; i<sections ; i++){
                sections[i].scrollIntoView({behavior: "smooth"});
            }
        });
    });

};

scrolling();

